
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'jcss1462org',
  applicationName: 'holamundo',
  appUid: 'sDZtp3GFZZZv8SVTKh',
  orgUid: 'a577ed36-6e09-4535-9305-7acb0e6403dd',
  deploymentUid: '2997242f-a558-4464-8092-dd4e04ec6ac1',
  serviceName: 'crud-serverless-user',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'crud-serverless-user-dev-create-users', timeout: 6 };

try {
  const userHandler = require('./createUsers/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createUsers, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}