
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'jcss1462org',
  applicationName: 'holamundo',
  appUid: 'sDZtp3GFZZZv8SVTKh',
  orgUid: 'a577ed36-6e09-4535-9305-7acb0e6403dd',
  deploymentUid: '78285238-5815-4de9-b595-a80b928c72ab',
  serviceName: 'crud-serverless-user',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'crud-serverless-user-dev-get-users', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getUsers, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}