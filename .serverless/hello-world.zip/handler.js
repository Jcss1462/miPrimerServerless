
const hello = async (event, context) => {
    return {
        "statusCode": 200,
        "body": JSON.stringify({ 'message': 'actualizada'})
    }
}

module.exports = {
    hello
}
